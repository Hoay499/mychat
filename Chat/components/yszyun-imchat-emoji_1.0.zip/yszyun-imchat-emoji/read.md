本组件根据hello uni-app 中聊天窗口chat  改造而成的表情组件。
引用 res.wx.qq.com 的表情库

说明：目前支持平台有APP、微信小程序、H5，其他平台理论上支持。